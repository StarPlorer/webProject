package com.koreait.mapper;


import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.koreait.domain.Criteria;
import com.koreait.domain.UserDTO;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@RunWith(SpringJUnit4ClassRunner.class)
public class CommunityMapperTest {
	@Setter(onMethod_ = @Autowired)
	private CommunityMapper mapper;
	
/*	@Test
	public void loginTest() {
		LoginDTO login = new LoginDTO("apple","강남구");
		log.info(mapper.login(login));
	}*/
	
/*	@Test
	public void getListWithPaging() {
		Criteria cri = new Criteria(3, 10);
		LoginDTO login = new LoginDTO("apple","강남구");
		cri.setUser_area(login.getUser_area());
		log.info("==============================================================");
		log.info(mapper.getListWithPaging(cri).size());
		mapper.getListWithPaging(cri).forEach(board -> log.info(board));
	}*/
	


}