package com.koreait.controller;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;

import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({"file:src/main/webapp/WEB-INF/spring/appServlet/servlet-context.xml",
	"file:src/main/webapp/WEB-INF/spring/root-context.xml"})
@Log4j
@WebAppConfiguration
public class CommunityControllerTests {
	@Setter(onMethod_ = @Autowired)
	private WebApplicationContext wac;
	
	//가짜 MVC
	//마치 브라우저에서 사용하는 것처럼 만들어서 Controller를 실행해 볼 수 있다.
	private MockMvc mockMvc;
	
	@Before//org.junit
	//@Before : 적용된 메소드를 모든 테스트 전에 매번 한번씩 실행한다.
	public void setup() {
		//			건축가		받아온 wac로 헬멧,로프,... 세팅	건축
		mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
	}
	

	
/*	@Test
	public void loginTest() throws Exception{
		log.info(
				mockMvc.perform(
						MockMvcRequestBuilders.post("/community/board/loginNext")
						.param("user_id", "apple")
						.param("user_area", "강남구")
						)
						.andReturn()
						.getModelAndView()
						.getModelMap()
				);
		
	}*/
	
	@Test
	public void listTest() throws Exception{
		log.info(
				mockMvc.perform(
						MockMvcRequestBuilders.post("/community/board/communityList")
						.param("pageNum", "2")
						.param("amount", "15")
						.param("user_area", "강남구")
						)
						.andReturn()
						.getModelAndView()
						.getModelMap()
				);
	}
	
	


}
