package com.koreait.service;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.koreait.domain.Criteria;
import com.koreait.domain.UserDTO;
import com.koreait.service.CommunityService;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class CommunityServiceTest {
	
	@Setter(onMethod_ = @Autowired)
	private CommunityService service;
	
/*	@Test
	public void loginTest() {
		LoginDTO login = new LoginDTO("apple","강남구");
		log.info(service.login(login));
	}*/
	
/*	@Test
	public void getTotalTest() {
		Criteria cri = new Criteria(3,10);
		cri.setUser_area("강남구");
		
		log.info("==========================");
		log.info(service.getTotal(cri));
	}*/

/*	@Test
	public void getListTest() {
		Criteria cri = new Criteria(3, 10);
		cri.setUser_area("강남구");
		log.info("=====================겟리스트 테스트============");
		log.info(service.getList(cri));
	}*/
	
}
