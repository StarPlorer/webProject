package com.koreait.mapper;

import java.util.List;
import java.util.Map;

import com.koreait.domain.SearchCriteria;
import com.koreait.domain.TradeBoardDTO;
import com.koreait.domain.TradeReplyDTO;

public interface TradeMapper {
	
	int insert(TradeBoardDTO BoardDTO); // 게시글 업로드 기능 
	List<TradeBoardDTO> listPage(SearchCriteria scri);// 게시물 목록 조회
	TradeBoardDTO read (Long bno);//게시물 조회
	void update(TradeBoardDTO boarddto);//게시글 수정
	void delete(Long BOARD_NUMBER);//게시글 삭제
	void updateViews(Long BOARD_NUMBER);//조회수 증가
	int listCount(SearchCriteria scri);//게시글 총 갯수
	List<TradeReplyDTO> readReply (Long bno);//댓글 조회
	void writeReply(TradeReplyDTO dto);//댓글 작성
	
	void updateReply(TradeReplyDTO reply);//댓글 수정
	
	void deleteReply(int rno);//댓글 삭제
	void insertFile( Map<String, Object> map);//게시글 파일 업로드
	List<Map<String, Object>> selectFileList (int bno);//업로드된 파일 조회
	public Map<String, Object> selectFileInfo(Map<String, Object> map);//첨부파일 다운로드
	public void updateFile(Map<String, Object> map);//첨부파일 수정
}
