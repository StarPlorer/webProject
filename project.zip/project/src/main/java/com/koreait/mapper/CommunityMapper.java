package com.koreait.mapper;


import java.util.List;
import java.util.Map;

import com.koreait.domain.BoardDTO;
import com.koreait.domain.CommunityReplyDTO;
import com.koreait.domain.Criteria;
import com.koreait.domain.UserDTO;

public interface CommunityMapper {
	
	UserDTO login(UserDTO login);//임시 로그인 기능 나중에 지울것 !
	
	List<BoardDTO> listPage(Criteria cri); //게시판 목록 불러오는 기능
	
	int listCount(Criteria cri); //게시판 총 갯수
	
	int getTotal(Criteria cri); //게시판 리스트 불러오는 기능
	
	List<BoardDTO> getListWithPaging(Criteria cri); //게시판 리스트 불러오는 기능
	
	BoardDTO read(Long BOARD_NUMBER);// 글 읽기 기능

	void updateViews(Long BOARD_NUMBER); //조회수 올라가는 기능
	
	int deleteView(Long BOARD_NUMBER); //게시글 삭제 기능
	
	int insertBoard(BoardDTO BoardDTO); // 게시글 업로드 기능 

	void insertFile( Map<String, Object> map);//게시글 파일 업로드
	
	List<Map<String, Object>> selectFileList (int bno);//업로드된 파일 조회
	
	Map<String, Object> selectFileInfo(Map<String, Object> map); //업로드된 파일 다운로드

	void update(BoardDTO boardDTO);// 게시판 수정
	
	void updateFile(Map<String, Object> map); //업로드된 파일 수정
	
	void deleteFile(Long BOARD_NUMBER); //업로드된 파일 삭제하기
	
	List<CommunityReplyDTO> readReply(Long bno); //댓글 조회
	
	void writeReply(CommunityReplyDTO reply); //댓글 작성
	
	void updateReply(CommunityReplyDTO reply);//댓글 수정
	
	void deleteReply(int rno);//댓글 삭제
	
	
}
