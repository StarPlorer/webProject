package com.koreait.mapper;

import java.util.List;
import java.util.Map;

import com.koreait.domain.InformationBoardDTO;
import com.koreait.domain.InformationReplyDTO;
import com.koreait.domain.SearchCriteria;

public interface InformationMapper {
	int insert(InformationBoardDTO BoardDTO); // 게시글 업로드 기능 
	List<InformationBoardDTO> listPage(SearchCriteria scri);// 게시물 목록 조회
	InformationBoardDTO read (Long bno);//게시물 조회
	void update(InformationBoardDTO boarddto);//게시글 수정
	void delete(Long BOARD_NUMBER);//게시글 삭제
	void updateViews(Long BOARD_NUMBER);//조회수 증가
	int listCount(SearchCriteria scri);//게시글 총 갯수
	List<InformationReplyDTO> readReply (Long bno);//댓글 조회
	void writeReply(InformationReplyDTO dto);//댓글 작성
	
	void updateReply(InformationReplyDTO reply);//댓글 수정
	
	void deleteReply(int rno);//댓글 삭제
	void insertFile( Map<String, Object> map);//게시글 파일 업로드
	List<Map<String, Object>> selectFileList (int bno);//업로드된 파일 조회
	public Map<String, Object> selectFileInfo(Map<String, Object> map);//첨부파일 다운로드
	public void updateFile(Map<String, Object> map);//첨부파일 수정
}
