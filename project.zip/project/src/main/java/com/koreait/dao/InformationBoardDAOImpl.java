package com.koreait.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.koreait.domain.InformationBoardDTO;
import com.koreait.domain.InformationReplyDTO;
import com.koreait.domain.SearchCriteria;
import com.koreait.domain.TradeBoardDTO;
import com.koreait.domain.TradeReplyDTO;
import com.koreait.mapper.InformationMapper;
import com.koreait.mapper.TradeMapper;

import lombok.Setter;

@Repository
public class InformationBoardDAOImpl implements InformationBoardDAO {
	
	@Setter(onMethod_ = @Autowired)
	private InformationMapper mapper;
	
	//게시글 작성
	@Override
	public void write(InformationBoardDTO boarddto) throws Exception{
		mapper.insert(boarddto);
	}
	
	// 게시물 목록 조회
	@Override
	public List<InformationBoardDTO> list(SearchCriteria scri) throws Exception{
		return mapper.listPage(scri);
	}
	//게시물 조회
	@Override
	public InformationBoardDTO read(Long bno) throws Exception{
		return mapper.read(bno);
	}
	//게시글 수정
	@Override
	public void update(InformationBoardDTO boarddto) throws Exception{
		mapper.update(boarddto);
	}
	//게시글 삭제
	@Override
	public void delete(Long BOARD_NUMBER) throws Exception{
		mapper.delete(BOARD_NUMBER);
	}
	//조회수 증가
	@Override
	public void updateviews(Long BOARD_NUMBER) throws Exception{
		mapper.updateViews(BOARD_NUMBER);
	}
	//게시물 총 갯수
	@Override
	public int listCount(SearchCriteria scri) throws Exception{
		return mapper.listCount(scri);
	}
	
	//댓글 조회
	@Override
	public List<InformationReplyDTO> readReply(Long bno) throws Exception{
		return mapper.readReply(bno);
	}
	
	//댓글 작성
	@Override
	public void writeReply (InformationReplyDTO dto) throws Exception{
		mapper.writeReply(dto);
	}
	
	//댓글 수정
	@Override
	public void updateReply(InformationReplyDTO replyDTO) throws Exception{
		mapper.updateReply(replyDTO);
	}
	//댓글 삭제
	public void deleteReply(int rno) throws Exception{
		mapper.deleteReply(rno);
	}
	//첨부파일 업로드
	@Override
	public void insertFile(Map<String, Object> map) throws Exception{
		mapper.insertFile(map);
	}
	//첨부파일 조회
	@Override
	public List<Map<String, Object>> selectFileList(int bno) throws Exception{
		return mapper.selectFileList(bno);
	}
	//첨부파일 다운로드
	@Override
	public Map<String, Object> selectFileInfo(Map<String, Object> map) throws Exception{
		return mapper.selectFileInfo(map);
	}
	//첨부파일 수정
	@Override
	public void updateFile(Map<String, Object> map) throws Exception{
		mapper.updateFile(map);
	}
}
