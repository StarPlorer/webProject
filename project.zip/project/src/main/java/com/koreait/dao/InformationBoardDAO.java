package com.koreait.dao;

import java.util.List;
import java.util.Map;

import com.koreait.domain.InformationBoardDTO;
import com.koreait.domain.InformationReplyDTO;
import com.koreait.domain.SearchCriteria;
import com.koreait.domain.TradeBoardDTO;
import com.koreait.domain.TradeReplyDTO;

public interface InformationBoardDAO {

	//게시글 작성
	public void write(InformationBoardDTO boarddto) throws Exception;
	//게시글 목록 조회
	public List<InformationBoardDTO> list(SearchCriteria scri) throws Exception;
	//게시물 총 갯수
	public int listCount(SearchCriteria scri) throws Exception;
	//게시글 조회
	public InformationBoardDTO read(Long bno) throws Exception;
	//게시글 수정
	public void update(InformationBoardDTO boarddto) throws Exception;
	//게시글 삭제
	public void delete(Long bno) throws Exception;
	//조회수 증가
	public void updateviews(Long bno) throws Exception;
	//댓글 조회
	public List<InformationReplyDTO> readReply(Long bno) throws Exception;
	//댓글 작성
	public void writeReply(InformationReplyDTO dto) throws Exception;
	public void updateReply(InformationReplyDTO replyDTO) throws Exception; //댓글 수정
	public void deleteReply(int rno) throws Exception;//댓글 삭제
	//첨부파일 업로드
	public void insertFile(Map<String, Object> map) throws Exception;
	//첨부파일 조회
	public List<Map<String, Object>> selectFileList(int bno) throws Exception;
	//첨부파일 다운로드
	public Map<String, Object> selectFileInfo(Map<String,Object> map) throws Exception;
	//첨부파일 수정
	public void updateFile(Map<String,Object> map) throws Exception;
	
}
