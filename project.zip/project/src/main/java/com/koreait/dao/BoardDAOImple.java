package com.koreait.dao;


import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.koreait.domain.BoardDTO;
import com.koreait.domain.CommunityReplyDTO;
import com.koreait.domain.Criteria;
import com.koreait.domain.SearchCriteria;
import com.koreait.mapper.CommunityMapper;


import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Repository //DAO객체에 필요한 어노테이션
public class BoardDAOImple implements BoardDAO {
	
	@Setter(onMethod_ = @Autowired)
	private CommunityMapper mapper;
	

	//게시글 목록
	@Override
	public List<BoardDTO> list(SearchCriteria scri) throws Exception{
		return mapper.listPage(scri);
	}
	//게시글 총 갯수
	@Override
	public int listCount(SearchCriteria scri) throws Exception {
		// TODO Auto-generated method stub
		return mapper.listCount(scri);
	}
	
	//게시글 업로드
	@Override
	public void write(BoardDTO board) throws Exception{
		mapper.insertBoard(board);//
	}
	
	//첨부파일 업로드
	@Override
	public void insertFile(Map<String, Object> map) throws Exception {
		// TODO Auto-generated method stub
		mapper.insertFile(map);
	}
	
	//첨부 파일 조회
	@Override
	public List<Map<String, Object>> selectFileList(int bno) throws Exception{
		return mapper.selectFileList(bno);
	}

	@Override
	public Map<String, Object> selectFileInfo(Map<String, Object> map) throws Exception {
		// TODO Auto-generated method stub
		return mapper.selectFileInfo(map);
	}
	
	@Override
	public void update(BoardDTO boardDTO) {
		mapper.update(boardDTO);
	}
	
	@Override
	public void updateFile(Map<String, Object> map) {
		mapper.updateFile(map);
	}
	
	@Override
	public void deleteFile(Long BOARD_NUMBER) {
		mapper.deleteFile(BOARD_NUMBER);
	}
	
	//댓글조회
	@Override
	public List<CommunityReplyDTO> readReply(Long bno) throws Exception{
		return mapper.readReply(bno);
	}
	
	//댓글작성
	@Override
	public void writeReply(CommunityReplyDTO replyDTO) throws Exception{
		mapper.writeReply(replyDTO);
	}
	
	//댓글 수정
	@Override
	public void updateReply(CommunityReplyDTO replyDTO) throws Exception{
		mapper.updateReply(replyDTO);
	}
	//댓글 삭제
	public void deleteReply(int rno) throws Exception{
		mapper.deleteReply(rno);
	}



	
	
}
