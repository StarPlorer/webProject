package com.koreait.dao;

import java.util.List;
import java.util.Map;

import com.koreait.domain.BoardDTO;
import com.koreait.domain.CommunityReplyDTO;
import com.koreait.domain.Criteria;
import com.koreait.domain.SearchCriteria;

public interface BoardDAO {
	public List<BoardDTO> list(SearchCriteria scri) throws Exception;//게시글 목록 조회
	public int listCount(SearchCriteria scri) throws Exception; // 게시물 총 갯수
	public void write(BoardDTO board) throws Exception;//게시글 작성
	public void insertFile(Map<String, Object> map) throws Exception; //첨부 파일 업로드
	public List<Map<String, Object>> selectFileList(int bno) throws Exception; //첨부 파일 조회
	public Map<String, Object> selectFileInfo(Map<String, Object> map) throws Exception; //첨부 파일 다운로드
	public void update(BoardDTO boardDTO) throws Exception;//게시판 수정
	public void updateFile(Map<String, Object> map) throws Exception; // 첨부파일 수정
	public void deleteFile(Long BOARD_NUMBER); //파일삭제
	public List<CommunityReplyDTO> readReply(Long bno) throws Exception;//댓글 조회
	public void writeReply(CommunityReplyDTO replyDTO) throws Exception; //댓글 작성
	public void updateReply(CommunityReplyDTO replyDTO) throws Exception; //댓글 수정
	public void deleteReply(int rno) throws Exception;//댓글 삭제
}
