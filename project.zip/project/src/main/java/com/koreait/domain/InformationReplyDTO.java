package com.koreait.domain;

import java.sql.Date;

import lombok.Data;

@Data
public class InformationReplyDTO {
	private Long bno;
	private int rno;
	private String content;
	private String writer;
	private Date regdate;
	
	@Override
	public String toString() {
		return "InformationReplyDTO [bno=" + bno + ", rno=" + rno + ", content=" + content + ", writer=" + writer + ", regdate="
				+ regdate + "]";
	}
}
