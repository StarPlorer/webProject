package com.koreait.domain;

import java.sql.Date;

import lombok.Data;

@Data
public class CommunityReplyDTO {
	private Long bno;
	private int rno;
	private String content;
	private String writer;
	private Date regdate;
	
	@Override
	public String toString() {
		return "CommunityReplyDTO [bno=" + bno + ", rno=" + rno + ", content=" + content + ", writer=" + writer + ", regdate="
				+ regdate + "]";
	}
}
