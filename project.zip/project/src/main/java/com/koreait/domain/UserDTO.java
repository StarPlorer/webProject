package com.koreait.domain;

import lombok.Data;

@Data
public class UserDTO {
	private String user_id;
	private String user_pw;
	private String user_name;
	private String user_mail;
	private String user_phone;
	private String user_addr;
	private String user_area;
	private String user_view_ok;
	private String user_write_ok;
	private String user_activate;
	
	public UserDTO(String user_id, String user_pw) {
		this.user_id= user_id;
		this.user_pw= user_pw;
	}
	
	public UserDTO() {
		
	}
	
}
