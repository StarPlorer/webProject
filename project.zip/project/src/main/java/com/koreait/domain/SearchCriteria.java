package com.koreait.domain;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class SearchCriteria extends Criteria{
	
	private String searchType = "";
	private String keyword = "";
	
	@Override
	public String toString() {
		return "SearchCriteria [searchType=" + searchType + ", keyword=" + keyword + "]";
	}

}
