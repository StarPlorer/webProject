package com.koreait.domain;

import lombok.Data;

@Data
public class BoardDTO {
	private Long BOARD_NUMBER;
	private String BOARD_TITLE;
	private String BOARD_CONTENT;
	private String BOARD_WRITER;
	private String BOARD_DATE;
	private String BOARD_VIEWS;
	private String BOARD_AREA;
}
