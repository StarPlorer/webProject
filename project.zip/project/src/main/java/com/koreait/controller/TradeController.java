package com.koreait.controller;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.request;

import java.io.File;


import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLEncoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.koreait.domain.BoardDTO;
import com.koreait.domain.CommunityReplyDTO;
import com.koreait.domain.PageMaker;
import com.koreait.domain.SearchCriteria;
import com.koreait.domain.TradeBoardDTO;
import com.koreait.domain.TradeReplyDTO;
import com.koreait.service.TradeBoardService;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Controller
@RequestMapping("trade/*")
public class TradeController {
	@Setter(onMethod_ = @Autowired)
	private TradeBoardService service;

	
	
	//거래 게시판 이동
	@GetMapping("/board/tradeList")
	public String list(SearchCriteria scri, Model model,HttpServletRequest request) throws Exception {
		HttpSession session = request.getSession();
		String user_area = (String)session.getAttribute("user_area");
		scri.setUser_area(user_area);

		System.out.println("거래 게시판으로 이동");
	
		
		PageMaker pageMaker = new PageMaker();
		pageMaker.setUser_area(user_area);
		pageMaker.setCri(scri);
		pageMaker.setTotalCount(service.listCount(scri));
		System.out.println("리스트 카운터 지난 부분");
		model.addAttribute("pageMaker", pageMaker);
		
		model.addAttribute("list",service.list(scri));
		System.out.println("리시트 지난 부분");
		
		return "trade/board/tradeList";
	}
	

	// 게시판 글 작성 페이지로 이동
	@GetMapping("/board/tradeWrite")
	public void tradeWrite(){
		System.out.println("글쓰기 페이지로 이동");
	}
	
	
	// 게시판 글 작성
		@PostMapping("/board/tradeWriteOk")
		public String tradeWriteOk(Model model, TradeBoardDTO board,RedirectAttributes ra, MultipartHttpServletRequest mpRequest) throws Exception{
			System.out.println("글 작성 완료!!");
			System.out.println(board.getBOARD_AREA());
			System.out.println(board.getBOARD_CONTENT());
			System.out.println(board.getBOARD_DATE());
			System.out.println(board.getBOARD_TITLE());
			System.out.println(board.getBOARD_TYPE());
			System.out.println(board.getBOARD_VIEWS());
			System.out.println(board.getBOARD_WRITER());
			System.out.println(board.getBOARD_NUMBER());
	
		
			
			service.write(board, mpRequest);
			
			ra.addFlashAttribute("result", board.getBOARD_NUMBER());
			
		
			
			//게시글에 있는 업로드된 파일 가져오기
		//	List<Map<String, Object>> fileList = service.selectFileList(Integer.parseInt(String.valueOf(board.getBOARD_NUMBER())));
		//	model.addAttribute("file", fileList);
			
			
			//게시글 정보 가져오기
			model.addAttribute("board",service.read(board.getBOARD_NUMBER()));
			

			return "trade/board/tradeView";
		}
		
		
		//게시물 상세 페이지로 이동
		@GetMapping("/board/tradeView")
		public String view(Model model, long BOARD_NUMBER , HttpServletRequest request) throws Exception{
			HttpSession session = request.getSession();
			String user_area = (String)session.getAttribute("user_area");
			String user_id = (String)session.getAttribute("user_id");
		
			//게시글 정보 가져오기
			model.addAttribute("board",service.read(BOARD_NUMBER));
			
			//게시글에 있는 업로드된 파일 가져오기
			List<Map<String, Object>> fileList = service.selectFileList((int)BOARD_NUMBER);
			model.addAttribute("file", fileList);
			
			
			//댓글 불러오기
			List<TradeReplyDTO> replyList = service.readReply(BOARD_NUMBER);
	
			model.addAttribute("replyList",replyList);
			
			return "trade/board/tradeView";
			
		}
		

		//업로드된 파일 다운로드
		@PostMapping("/board/fileDown")
		public void fileDown(@RequestParam Map<String, Object> map, HttpServletResponse response) throws Exception{
			System.out.println(map);
			Map<String, Object> resultMap = service.selectFileInfo(map);
			System.out.println(resultMap);
			String storedFileName = (String) resultMap.get("STORED_FILE_NAME");
			String originalFileName = (String) resultMap.get("ORG_FILE_NAME");
			System.out.println("파일 다운로드 컨트롤러 접근완료");
			//파일을 저장했던 위치에서 첨부파일을 읽어 BYTE[]형식으로 변환
			byte fileByte[] = org.apache.commons.io.FileUtils.readFileToByteArray(new File("C:\\1900_WEB_BSB\\Spring\\workspace\\project\\src\\main\\webapp\\WEB-INF\\views\\trade\\file\\tradefileStorageCheck"+storedFileName));
			
			response.setContentType("application/octet-stream");
			response.setContentLength(fileByte.length);
			response.setHeader("Content-Dispostion", "attachment); fileName=\""+URLEncoder.encode(originalFileName,"UTF-8")+"\";");
			response.getOutputStream().write(fileByte);
			response.getOutputStream().flush();
			response.getOutputStream().close();
			System.out.println("파일 다운로드 컨트롤러 완료 ");
		}
		//게시판 수정 뷰
		@GetMapping("/board/updateView")
		public String updateView(long BOARD_NUMBER, Model model, HttpServletRequest request) throws Exception{
			HttpSession session = request.getSession();
			String user_area = (String)session.getAttribute("user_area");
			String user_id = (String)session.getAttribute("user_id");
		
			//게시글 정보 가져오기
			model.addAttribute("board",service.read(BOARD_NUMBER));
			
			//게시글에 있는 업로드된 파일 가져오기
			List<Map<String, Object>> fileList = service.selectFileList((int)BOARD_NUMBER);
			model.addAttribute("file", fileList);
			
			
			return "trade/board/tradeUpdate";
		}

		//게시판 수정완료
		@PostMapping("/board/update")
		public String update(TradeBoardDTO boardDTO, @RequestParam(value="fileNoDel[]") String[] files, @RequestParam(value="fileNameDel[]") String[] fileNames, MultipartHttpServletRequest mpRequest,Model model,RedirectAttributes ra) throws Exception{
			
			System.out.println("컨트롤러에 들어왔다");
			System.out.println(boardDTO.getBOARD_TITLE());
			System.out.println(boardDTO.getBOARD_CONTENT());
			service.update(boardDTO, files, fileNames, mpRequest);

		
			
			
			ra.addFlashAttribute("result", boardDTO.getBOARD_NUMBER());
			
			//redirect: 접두어를 사용하면 스프링 MVC가 자동으로 redirect로 처리해준다.
		//	return "redirect:/community/board/list";
			
			//게시글에 있는 업로드된 파일 가져오기
			
			List<Map<String, Object>> fileList = service.selectFileList(Integer.parseInt(String.valueOf(boardDTO.getBOARD_NUMBER())));
			model.addAttribute("file", fileList);
			
			
			//게시글 정보 가져오기
			model.addAttribute("board",service.read(boardDTO.getBOARD_NUMBER()));

			return "trade/board/tradeView";
		}
		
		//게시글 삭제
		@GetMapping("/board/delete")
		public String delete(Long BOARD_NUMBER, RedirectAttributes rttr) throws Exception {
			service.delete(BOARD_NUMBER);
			return "redirect:/trade/board/tradeList";
		}
		
		//댓글 작성
		@PostMapping("/board/replywrite")
		public String replyWrite(TradeReplyDTO dto, SearchCriteria scri, RedirectAttributes rttr, Model model) throws Exception{
			
		service.writeReply(dto);

		//게시글 정보 가져오기
			model.addAttribute("board",service.read(dto.getBno()));
			
			//댓글 불러오기
			List<TradeReplyDTO> replyList = service.readReply(dto.getBno());
			model.addAttribute("replyList",replyList);
			System.out.println(replyList);
			
	//게시글에 있는 업로드된 파일 가져오기
			
			int BOARD_NUMBER = Integer.parseInt(String.valueOf(dto.getBno()));
			List<Map<String, Object>> fileList = service.selectFileList((int)BOARD_NUMBER);
			model.addAttribute("file", fileList);
			return "trade/board/tradeView";
		
		}
		
		//댓글 수정
		@GetMapping("/board/replyupdate")
		public String replyUpdate(TradeReplyDTO rdto,Model model) throws Exception {
			System.out.println(rdto.getContent());
			System.out.println(rdto.getRno());
			service.updateReply(rdto);
			
			//게시글 정보 가져오기
			model.addAttribute("board",service.read(rdto.getBno()));
		//게시글에 있는 업로드된 파일 가져오기
			
			int BOARD_NUMBER = Integer.parseInt(String.valueOf(rdto.getBno()));
			List<Map<String, Object>> fileList = service.selectFileList((int)BOARD_NUMBER);
			model.addAttribute("file", fileList);
			
			
			//댓글 불러오기
			List<TradeReplyDTO> replyList = service.readReply(rdto.getBno());
			model.addAttribute("replyList",replyList);
			return "trade/board/tradeView";
			
			
		}
		//댓글삭제
		@GetMapping("board/deleteReply")
		public String deleteReply(int rno,Model model,Long bno) throws Exception {
			service.deleteReply(rno);
			//게시글 정보 가져오기
			System.out.println("댓글 지움 서비스 지나감");
					model.addAttribute("board",service.read(bno));
					System.out.println("게시글 정보 가져옴");
				//게시글에 있는 업로드된 파일 가져오기
					
			//		int BOARD_NUMBER = Integer.parseInt(String.valueOf(bno));
				//	List<Map<String, Object>> fileList = service.selectFileList((int)BOARD_NUMBER);
				//	System.out.println("파일 불러옴");
				//	model.addAttribute("file", fileList);
					
					
					//댓글 불러오기
					List<TradeReplyDTO> replyList = service.readReply(bno);
					System.out.println("댓글 가져옴");
					model.addAttribute("replyList",replyList);
					return "trade/board/tradeView";
			
		}
}
