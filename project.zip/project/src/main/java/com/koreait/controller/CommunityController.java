package com.koreait.controller;

import java.io.File;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.koreait.domain.BoardDTO;
import com.koreait.domain.CommunityReplyDTO;
import com.koreait.domain.Criteria;
import com.koreait.domain.UserDTO;
import com.koreait.domain.PageMaker;
import com.koreait.domain.SearchCriteria;
import com.koreait.service.CommunityService;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLEncoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@RequestMapping("community/*")
public class CommunityController { //임시 로그인 페이지 여는 부분
	@Setter(onMethod_ = @Autowired)
	private CommunityService service;
	
	@GetMapping("/board/loginPage")
	public void login() {
		
		System.out.println("로그인 페이지로 이동");
	}

	@PostMapping("/board/loginNext")
	public String login2(UserDTO login, Model model,HttpServletRequest request) {// 임시 로그인 기능이다 나중에 지울것
		log.info("------임시로그인 컨트롤러-------");
		
		
		UserDTO login2=service.login(login);
		
		log.info("---------------DB에 접근하여 로그인하기 성공-----------------");
		
		System.out.println(login2);
		System.out.println(login2.getUser_id());
		System.out.println(login2.getUser_pw());
		System.out.println(login2.getUser_area());
		
		HttpSession session = request.getSession(); //세션 설정
	    session.setAttribute("user_id", login2.getUser_id());
	    session.setAttribute("user_area", login2.getUser_area());
		session.setAttribute("user_view_ok", login2.getUser_view_ok());
		session.setAttribute("user_write_ok", login2.getUser_write_ok());
		session.setAttribute("user_activate", login2.getUser_activate());
	    
		model.addAttribute("user_id",login2.getUser_id());
		model.addAttribute("user_area",login2.getUser_area());
		model.addAttribute("user_view_ok",login2.getUser_view_ok());
		model.addAttribute("user_write_ok",login2.getUser_write_ok());
		model.addAttribute("user_activate",login2.getUser_activate());
		
		return "community/board/loginNext";
	}
	
	@GetMapping("/board/communityList")
	public String list(SearchCriteria scri, Model model,HttpServletRequest request) throws Exception {
		HttpSession session = request.getSession();
		String user_area = (String)session.getAttribute("user_area");
		scri.setUser_area(user_area);

		System.out.println("커뮤니티 게시판으로 이동");
	
	
		
		PageMaker pageMaker = new PageMaker();
		pageMaker.setUser_area(user_area);
		pageMaker.setCri(scri);
		pageMaker.setTotalCount(service.listCount(scri));
		
		model.addAttribute("pageMaker", pageMaker);
		
		model.addAttribute("list",service.list(scri));
		
		return "community/board/communityList";
	}

//	//아래의 메소드는 /get 이나 /modify인 경우에 호출되게 되는데
//	//그 때 호출하는 uri대로 view를 찾을것이다.
//	//즉 /get으로 요청해서 호출됐다면 get.jsp를, /modify로 요청해서 호출됐다면 modify.jsp를 찾게된다.
//	@GetMapping({"/board/communityView","/modify"})
//	public void get(Long boardnum, @ModelAttribute("cri") Criteria cri, Model model) {
//		log.info("------/get or /modify------");
//		model.addAttribute("board",service.get(boardnum));
//		//http://localhost:9090/community/board/45
//	}
//
	
	//게시물 상세 페이지로 이동
	@GetMapping("/board/communityView")
	public String view(Model model, long BOARD_NUMBER , HttpServletRequest request) throws Exception{
		log.info("------/get or /modify------");
		HttpSession session = request.getSession();
		String user_area = (String)session.getAttribute("user_area");
		String user_id = (String)session.getAttribute("user_id");
	
		//게시글 정보 가져오기
		model.addAttribute("board",service.get(BOARD_NUMBER));
		
		//게시글에 있는 업로드된 파일 가져오기
		List<Map<String, Object>> fileList = service.selectFileList((int)BOARD_NUMBER);
		model.addAttribute("file", fileList);
		
		
		//댓글 불러오기
		List<CommunityReplyDTO> replyList = service.readReply(BOARD_NUMBER);
		model.addAttribute("replyList",replyList);
		
		//게시글 조회수 올리기
		service.updateViews(BOARD_NUMBER);
		return "community/board/communityView";
		
	}
	
	@GetMapping("/board/deleteView")
	public String viewDelete(Long BOARD_NUMBER, RedirectAttributes rttr) {
		service.deleteView(BOARD_NUMBER);
		rttr.addFlashAttribute("result","삭제되었습니다");
		return "redirect:/community/board/communityList";
	}
	
	// 게시판 글 작성 페이지로 이동
	@GetMapping("/board/communityWrite")
	public void communityWrite(){
		System.out.println("글쓰기 페이지로 이동");
	}
	
	// 게시판 글 작성
	@PostMapping("/board/communityWriteOk")
	public String communityWriteOk(Model model, BoardDTO board,RedirectAttributes ra, MultipartHttpServletRequest mpRequest) throws Exception{
		System.out.println("글 작성 완료!!");
		service.write(board,mpRequest);
		System.out.println(board);
		ra.addFlashAttribute("result", board.getBOARD_NUMBER());
		
		//redirect: 접두어를 사용하면 스프링 MVC가 자동으로 redirect로 처리해준다.
	//	return "redirect:/community/board/list";
	
		
		//게시글에 있는 업로드된 파일 가져오기
		List<Map<String, Object>> fileList = service.selectFileList(Integer.parseInt(String.valueOf(board.getBOARD_NUMBER())));
		model.addAttribute("file", fileList);
		
		
		//게시글 정보 가져오기
		model.addAttribute("board",service.get(board.getBOARD_NUMBER()));
		

		return "community/board/communityView";
	}
	
	//업로드된 파일 다운로드
	@PostMapping("/board/fileDown")
	public void fileDown(@RequestParam Map<String, Object> map, HttpServletResponse response) throws Exception{
		System.out.println(map);
		Map<String, Object> resultMap = service.selectFileInfo(map);
		System.out.println(resultMap);
		String storedFileName = (String) resultMap.get("STORED_FILE_NAME");
		String originalFileName = (String) resultMap.get("ORG_FILE_NAME");
		System.out.println("파일 다운로드 컨트롤러 접근완료");
		//파일을 저장했던 위치에서 첨부파일을 읽어 BYTE[]형식으로 변환
		byte fileByte[] = org.apache.commons.io.FileUtils.readFileToByteArray(new File("C:\\1900_WEB_BSB\\Spring\\workspace\\project\\src\\main\\webapp\\WEB-INF\\views\\community\\file\\communityfileStorageCheck"+storedFileName));
		
		response.setContentType("application/octet-stream");
		response.setContentLength(fileByte.length);
		response.setHeader("Content-Dispostion", "attachment); fileName=\""+URLEncoder.encode(originalFileName,"UTF-8")+"\";");
		response.getOutputStream().write(fileByte);
		response.getOutputStream().flush();
		response.getOutputStream().close();
		System.out.println("파일 다운로드 컨트롤러 완료 ");
	}
	
	
	//게시판 수정 뷰
	@GetMapping("/board/updateView")
	public String updateView(long BOARD_NUMBER, Model model, HttpServletRequest request) throws Exception{
		HttpSession session = request.getSession();
		String user_area = (String)session.getAttribute("user_area");
		String user_id = (String)session.getAttribute("user_id");
	
		//게시글 정보 가져오기
		model.addAttribute("board",service.get(BOARD_NUMBER));
		
		//게시글에 있는 업로드된 파일 가져오기
		List<Map<String, Object>> fileList = service.selectFileList((int)BOARD_NUMBER);
		model.addAttribute("file", fileList);
		
		
		return "community/board/communityUpdate";
	}
	
	//게시판 수정
	@PostMapping("/board/update")
	public String update(BoardDTO boardDTO,	MultipartHttpServletRequest mpRequest,Model model,RedirectAttributes ra) throws Exception{
		
		System.out.println("컨트롤러에 들어왔다");
		System.out.println(boardDTO.getBOARD_TITLE());
		System.out.println(boardDTO.getBOARD_CONTENT());
		service.update(boardDTO,mpRequest );

	
		
		
		ra.addFlashAttribute("result", boardDTO.getBOARD_NUMBER());
		
		//redirect: 접두어를 사용하면 스프링 MVC가 자동으로 redirect로 처리해준다.
	//	return "redirect:/community/board/list";
		
		//게시글에 있는 업로드된 파일 가져오기
		
		List<Map<String, Object>> fileList = service.selectFileList(Integer.parseInt(String.valueOf(boardDTO.getBOARD_NUMBER())));
		model.addAttribute("file", fileList);
		
		
		//게시글 정보 가져오기
		model.addAttribute("board",service.get(boardDTO.getBOARD_NUMBER()));

		return "community/board/communityView";
	}
	
	//댓글 작성
	@PostMapping("/board/replywirte")
	public String replyWrite(CommunityReplyDTO dto, RedirectAttributes ra,Model model) throws Exception{
		System.out.println("댓글작성 컨트롤러에 들어왔다");
		service.writeReply(dto);
		
		

		//게시글 정보 가져오기
		model.addAttribute("board",service.get(dto.getBno()));
		
		//게시글에 있는 업로드된 파일 가져오기
		
		int BOARD_NUMBER = Integer.parseInt(String.valueOf(dto.getBno()));
		List<Map<String, Object>> fileList = service.selectFileList((int)BOARD_NUMBER);
		model.addAttribute("file", fileList);
		
		
		//댓글 불러오기
		List<CommunityReplyDTO> replyList = service.readReply(dto.getBno());
		model.addAttribute("replyList",replyList);
		
		return "community/board/communityView";
	}

	
	//댓글 수정
	@GetMapping("/board/replyupdate")
	public String replyUpdate(CommunityReplyDTO rdto,Model model) throws Exception {
		System.out.println(rdto.getContent());
		System.out.println(rdto.getRno());
		service.updateReply(rdto);
		
		//게시글 정보 가져오기
		model.addAttribute("board",service.get(rdto.getBno()));
	//게시글에 있는 업로드된 파일 가져오기
		
		int BOARD_NUMBER = Integer.parseInt(String.valueOf(rdto.getBno()));
		List<Map<String, Object>> fileList = service.selectFileList((int)BOARD_NUMBER);
		model.addAttribute("file", fileList);
		
		
		//댓글 불러오기
		List<CommunityReplyDTO> replyList = service.readReply(rdto.getBno());
		model.addAttribute("replyList",replyList);
		return "community/board/communityView";
		
		
	}
	//댓글삭제
	@GetMapping("board/deleteReply")
	public String deleteReply(int rno,Model model,Long bno) throws Exception {
		service.deleteReply(rno);
		//게시글 정보 가져오기
		System.out.println("댓글 지움 서비스 지나감");
				model.addAttribute("board",service.get(bno));
				System.out.println("게시글 정보 가져옴");
			//게시글에 있는 업로드된 파일 가져오기
				
				int BOARD_NUMBER = Integer.parseInt(String.valueOf(bno));
				List<Map<String, Object>> fileList = service.selectFileList((int)BOARD_NUMBER);
				System.out.println("파일 불러옴");
				model.addAttribute("file", fileList);
				
				
				//댓글 불러오기
				List<CommunityReplyDTO> replyList = service.readReply(bno);
				System.out.println("댓글 가져옴");
				model.addAttribute("replyList",replyList);
				return "community/board/communityView";
		
	}
}
