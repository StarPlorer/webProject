package com.koreait.service;

import java.util.List;
import java.util.Map;

import org.apache.log4j.rewrite.ReflectionRewritePolicy;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.koreait.domain.BoardDTO;
import com.koreait.domain.Criteria;
import com.koreait.domain.UserDTO;
import com.koreait.domain.*;

public interface CommunityService {

	//comminity게시판에서 사용할 기능 이름들 정의 (현실적으로 사용자입장에서 정의할 것)
	public UserDTO login(UserDTO login); //임시 로그인 기능 나중에 지울 것 
	
	public List<BoardDTO> list(SearchCriteria scri) throws Exception;// 게시물 목록 조회
	
	public int listCount(SearchCriteria scri) throws Exception;// 게시물 총 갯수
	
	public int getTotal(Criteria cri); //게시판 불러오기
	
	public List<BoardDTO> getList(Criteria cri); // 게시판 불러오

	public BoardDTO get(Long BOARD_NUMBER);

	public void updateViews(Long BOARD_NUMBER);
	
	public int deleteView(Long BOARD_NUMBER);

	public void write(BoardDTO board, MultipartHttpServletRequest mpRequest) throws Exception;
	
	public List<Map<String, Object>> selectFileList(int bno) throws Exception;
	
	public Map<String, Object> selectFileInfo(Map<String, Object> map) throws Exception;
	
	public void update(BoardDTO bardDTO,MultipartHttpServletRequest mpRequest) throws Exception;
	
	public void deletefile(Long BOARD_NUMBER);
	
	public void writeReply(CommunityReplyDTO replyDTO) throws Exception; //댓글 작성

	public List<CommunityReplyDTO> readReply(Long bno) throws Exception; //댓글 조회
	
	public void updateReply(CommunityReplyDTO dto) throws Exception;// 댓글 수정

	public void deleteReply(int rno) throws Exception;//댓글 삭제
}
