package com.koreait.service;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.inject.Inject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.koreait.dao.BoardDAO;
import com.koreait.domain.BoardDTO;
import com.koreait.domain.CommunityReplyDTO;
import com.koreait.domain.Criteria;
import com.koreait.domain.SearchCriteria;
import com.koreait.domain.UserDTO;
import com.koreait.mapper.CommunityMapper;
import com.koreait.util.FileUtils;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service //서비스 객체
public class CommunityServiceImple implements CommunityService {

	@Setter(onMethod_ = @Autowired)
	private CommunityMapper mapper;
	
	@Setter(onMethod_ = @Autowired)
	private BoardDAO dao;
	
	@Override
	public UserDTO login(UserDTO login){
		log.info("--------임시 로그인  서비스 -------------");
		UserDTO result = mapper.login(login);
		return result;
	}

	
	@Override
	public int getTotal(Criteria cri) {
		
		return mapper.getTotal(cri);
	}
	
	@Override
	public List<BoardDTO> getList(Criteria cri) {
	
		log.info("-------getListWithPaging-------");
		return mapper.getListWithPaging(cri);
	}
	
	//게시물 목록조회
	@Override
	public List<BoardDTO> list(SearchCriteria scri) throws Exception{
		return dao.list(scri);
	}
	
	//게시물 총갯수
	@Override
	public int listCount(SearchCriteria scri) throws Exception{
		return dao.listCount(scri);
	}
	
	@Override
	public BoardDTO get(Long BOARD_NUMBER) {
		log.info("------get------");
		return mapper.read(BOARD_NUMBER);
	}

	@Override
	public void updateViews(Long BOARD_NUMBER) {
		mapper.updateViews(BOARD_NUMBER);
	}

	@Override
	public int deleteView(Long BOARD_NUMBER) {
		return mapper.deleteView(BOARD_NUMBER);
	}
	
	@Resource(name="fileUtils")
	private FileUtils fileUtils;


	//게시글 작성
	@Override
	public void write(BoardDTO board, MultipartHttpServletRequest mpRequest) throws Exception {
		dao.write(board);
		
		List<Map<String,Object>> list = fileUtils.parseInsertFileInfo(board, mpRequest); 
		int size = list.size();
		for(int i=0; i<size; i++){ 
			dao.insertFile(list.get(i)); 
		}
	}
	
	//첨부 파일 조회
	@Override
	public List<Map<String, Object>> selectFileList(int bno) throws Exception{
		return dao.selectFileList(bno);
	}
	
	//첨부파일 다운로드
	@Override
	public Map<String, Object> selectFileInfo(Map<String, Object> map) throws Exception {
		return dao.selectFileInfo(map);
	}
	
	//게시글 수정
	@Override
	public void update(BoardDTO boardDTO,MultipartHttpServletRequest mpRequest) throws Exception{
		dao.update(boardDTO);
		dao.deleteFile(boardDTO.getBOARD_NUMBER());
		
		List<Map<String,Object>> list = fileUtils.parseInsertFileInfo(boardDTO, mpRequest); 
		int size = list.size();
		for(int i=0; i<size; i++){ 
			dao.insertFile(list.get(i)); 
		}
		}
	
	
	//게시글의 업로드된 파일 삭제
	@Override
	public void deletefile(Long BOARD_NUMBER) {
		dao.deleteFile(BOARD_NUMBER);
	}
	
	//댓글작성
	@Override
	public void writeReply(CommunityReplyDTO replyDTO) throws Exception {
		dao.writeReply(replyDTO);
	}
	
	//댓글 조회
	@Override
	public List<CommunityReplyDTO> readReply(Long bno) throws Exception{
		return dao.readReply(bno);
	}
	
	//댓글 수정
	@Override
	public void updateReply(CommunityReplyDTO replyDTO) throws Exception{
		dao.updateReply(replyDTO);
	}
	
	//댓글 삭제
	@Override
	public void deleteReply(int rno) throws Exception{
		dao.deleteReply(rno);
	}
}
