package com.koreait.service;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.koreait.dao.InformationBoardDAO;
import com.koreait.dao.TradeBoardDAO;
import com.koreait.domain.CommunityReplyDTO;
import com.koreait.domain.InformationBoardDTO;
import com.koreait.domain.InformationReplyDTO;
import com.koreait.domain.SearchCriteria;
import com.koreait.domain.TradeBoardDTO;
import com.koreait.domain.TradeReplyDTO;
import com.koreait.mapper.TradeMapper;

import lombok.Setter;

import com.koreait.util.InformationFileUtils;
import com.koreait.util.TradeFileUtils;

@Service
public class InformationBoardServiceImpl implements InformationBoardService {
	
	@Setter(onMethod_ = @Autowired)
	private InformationBoardDAO dao;
	
	@Resource(name="InformationfileUtils")
	private InformationFileUtils fileUtils;
	
	//게시글 작성
	@Override
	public void write(InformationBoardDTO boarddto, MultipartHttpServletRequest mpRequest) throws Exception{
		dao.write(boarddto);
		List<Map<String,Object>> list = fileUtils.parseInsertFileInfo(boarddto, mpRequest); 
		int size = list.size();
		for(int i=0; i<size; i++){ 
			dao.insertFile(list.get(i)); 
			}
	}
	
	//게시물 목록 조회
	@Override
	public List<InformationBoardDTO> list(SearchCriteria scri) throws Exception{
		return dao.list(scri);
	}

	//게시물 조회
	@Override
	public InformationBoardDTO read(Long bno) throws Exception{
		dao.updateviews(bno);
		return dao.read(bno);
	}
	
	//게시글 수정
	@Override
	public void update(InformationBoardDTO boarddto, String[] files, String[] fileNames, MultipartHttpServletRequest mpReqeust) throws Exception{
		dao.update(boarddto);
		List<Map<String, Object>> list = fileUtils.parseUpdateFileInfo(boarddto, mpReqeust,files,fileNames);
		Map<String, Object> tempMap =null;
		int size = list.size();
		for(int i=0; i<size; i++) {
			tempMap = list.get(i);
			if(tempMap.get("IS_NEW").equals("Y")) {
				dao.insertFile(tempMap);
			}else {
				dao.updateFile(tempMap);
			}
		}
	}
	
	//게시글 삭제
	@Override
	public void delete(Long BOARD_NUMBER) throws Exception{
		dao.delete(BOARD_NUMBER);
	}
	
	//게시물 총 갯수
	@Override
	public int listCount(SearchCriteria scri) throws Exception{
		return dao.listCount(scri);
	}
	
	//댓글 조회
	@Override
	public List<InformationReplyDTO> readReply(Long bno) throws Exception{
		return dao.readReply(bno);
	}
	
	//댓글 작성
	@Override
	public void writeReply(InformationReplyDTO dto) throws Exception{
		dao.writeReply(dto);
	}
	
	//댓글 수정
	@Override
	public void updateReply(InformationReplyDTO replyDTO) throws Exception{
		dao.updateReply(replyDTO);
	}
	
	//댓글 삭제
	@Override
	public void deleteReply(int rno) throws Exception{
		dao.deleteReply(rno);
	}
	
	//첨부파일 조회
	@Override
	public List<Map<String, Object>> selectFileList(int bno) throws Exception{
		return dao.selectFileList(bno);
	}

	//첨부파일 다운로드
	@Override
	public Map<String, Object> selectFileInfo(Map<String, Object> map) throws Exception{
		return dao.selectFileInfo(map);
	}
	
	
}
